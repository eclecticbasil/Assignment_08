#------------------------------------------#
# Title: CD_Inventory.py
# Desc: Assignnment 08 - Working with classes
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, created file
# DBiesinger, 2030-Jan-01, added pseudocode to complete assignment 
# Rbukhari, 2022-Mar-21, adding code to classes CD, IO and FileIO
# and docstrings.
#------------------------------------------#
import pickle

# -- DATA -- #
strFileName = 'cdInventory.dat'
lstOfCDObjects = []
strChoice = ""

class CD:
    """Stores data about a CD.

    properties:
        cd_id: (int) with CD ID
        cd_title: (string) with the title of the CD
        cd_artist: (string) with the artist of the CD
    methods:
        __init__ 

    """
    
    # TODO Add Code to the CD class
    def __init__(self, cd_id, cd_title, cd_artist):
        self.__cd_id = cd_id
        self.__cd_title = cd_title
        self.__cd_artist = cd_artist
    """ constructor __init__
    
    Args: cd_id (int), cd_title (string) cd_artist (string)
    Returns: CD object
    """

    @property 
    def cd_id (self):
            return self.__cd_id
        
    """decorator @property and setters and getters used for reading and
    writing of the attributes"""
    
    @cd_id.setter
    def cd_id (self, value):
            self.__cd_id = value
        
    @property 
    def cd_title (self):
            return self.__cd_title
        
    @cd_title.setter
    def cd_title (self,value):
            self.__cd_title = value
    """ Title of CD"""
    @property
    def cd_artist(self):
            return self.__cd_artist
    
    @cd_artist.setter
    def cd_artist(self,value):
            self.__cd_artist = value
    """ Artist of CD """
# -- PROCESSING -- #
class FileIO:
    """Processes data to and from file - using pickle method here. Save 
    inventory using fileObj and loading inventory is using file obj added
    exceptions. 

    Properties: 

    Methods:
        save_inventory(file_name, lst_Inventory): -> None
        load_inventory(file_name): -> (a list of CD objects)

    """
    def save_inventory(self, file_name, lst_inventory):
        with open (file_name, "wb") as fileObj:
            pickle.dump(lst_inventory, fileObj)

    def load_inventory(self, file_name): # a list of CD objects
        # TODO Add code to process data from a file
        #table.clear()  # this clears existing data and allows to load data from file
        cdinventory = []
        try:
            with open (file_name, "rb") as fileObj: #pickling read file 
                 cdinventory = pickle.load(fileObj)
        except FileNotFoundError:
            print(" File not found. Continuing ...\n")
        except Exception:
            print ("Could not load data")
            
        return cdinventory
    
    
    # TODO Add code to process data to a file
    pass


# -- PRESENTATION (Input/Output) -- #
class IO:
    # TODO add docstring
    # TODO add code to show menu to user
    def print_menu(self):
        """Display menu to the user.

        Args: None.
        Returns: None.

        """
        print("Menu\n\n[l] load Inventory from file\n[a] Add CD\n[i] Display Current Inventory")
        print("[d] delete CD from Inventory\n[s] Save Inventory to file\n[x] exit\n")

    # TODO add code to captures user's choice
    def menu_choice(self):
        """Get user input for menu selection.

        Args: None

        Returns: choice (string)lowercase string of the users input out of 
        the choices l, a, i, d, s or x
        
        """
        choice = " "
        while choice not in ["l", "a", "i", "d", "s", "x"]:
            choice = input("Which operation would you like to perform? [l, a, i, d, s or x]: ").lower().strip()
        print()  # Add extra space for layout
        return choice
    
    # TODO add code to display the current data on screen
    def show_inventory(self, list):
        """Display current inventory table.
        
        Args:table (list of objects): 2D data structure (list of objects) that holds
        the data during runtime.
        Returns: None. 
        Added CD class proprties 
        """
        print("======= The Current Inventory: =======")
        print("ID\tCD Title (by: Artist)\n")
        for cd in list:
            print("{}\t{} (by:{})".format(cd.cd_id, cd.cd_title, cd.cd_artist))
        print("======================================")
        
    # TODO add code to get CD data from user
    def add_userinput(self):
        """Asking the user input.

        Args: None
        Return: None

        """
        # Using try/except
        strID = ""
        while True:
            strID = input ("Enter a number for ID:, \"x\" to exit:")
            if strID.lower() == "x":
                return
            try:
                intID = int(strID)
                break
            except ValueError:
                print("Please enter a number for ID.")

        strTitle = input("What is the CD\'s title? ").strip()
        strArtist = input("What is the Artist\'s name? ").strip()

        return intID, strTitle, strArtist
    
    def del_userinput(self):
        while True:
            try:
                intIDDel = int(input("Which ID would you like to delete? ").strip())
                return intIDDel
            except ValueError:
                print("Please enter a number for ID, or \"x\" to exit")
                continue
    pass

    def __str___(self):
        return self.noAnswer()
    
# -- Main Body of Script -- #
fileIO = FileIO()
io = IO()

lstOfCDObjects = fileIO.load_inventory(strFileName)

while True:
    # 2.1 Display Menu to user and get choice
    io.print_menu()
    menu_choice = io.menu_choice()

    # 3. Process menu selection
    # 3.1 process exit first
    if menu_choice == "x":
        break
    # 3.2 process load inventory
    if menu_choice == "l":
        print("WARNING: If you continue, all unsaved data will be lost and the Inventory will be re-loaded from file.")
        strYesNo = input("Type \"yes\" to continue and reload from file. otherwise reload will be canceled")
        if strYesNo.lower() == "yes":
            print("reloading...")
            lstOfCDObjects = fileIO.load_inventory(strFileName)
            io.show_inventory(lstOfCDObjects)
        else:
            input("canceling... Inventory data NOT reloaded. Press [ENTER] to continue to the menu.")
            io.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    # 3.3 process add a CD
    elif menu_choice == "a":
        # 3.3.1 Ask user for new ID, CD Title and Artist
        try: 
            intID, strTitle, strArtist = io.add_userinput()
        except TypeError:
            continue
        # 3.3.2 Add item to the table
        cd = CD(intID, strTitle, strArtist)
        lstOfCDObjects.append(cd)
        io.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    # 3.4 process display current inventory
    elif menu_choice == "i":
        io.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    # 3.5 process delete a CD
    elif menu_choice == "d":
        # 3.5.1 get Userinput for which CD to delete
        # 3.5.1.1 display Inventory to user
        io.show_inventory(lstOfCDObjects)
        # 3.5.1.2 ask user which ID to remove
        intIDDel = io.del_userinput()
        # 3.5.2 search thru table and delete CD
        intRowNr = -1
        blnCDRemoved = False
        for cd in lstOfCDObjects:
            intRowNr += 1
            if cd.cd_id == intIDDel:
                del lstOfCDObjects[intRowNr]
                print("The CD was removed")

            io.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    # 3.6 process save inventory to file
    elif menu_choice == "s":
        # 3.6.1 Display current inventory and ask user for confirmation to save
        io.show_inventory(lstOfCDObjects)
        strYesNo = input("Save this inventory to file? [y/n] ").strip().lower()
        # 3.6.2 Process choice
        if strYesNo == "y":
            # 3.6.2.1 save data
            fileIO.save_inventory(strFileName,lstOfCDObjects)
        else:
            input("The inventory was NOT saved to file. Press [ENTER] to return to the menu.")
        
        continue  # start loop back at top.
    # 3.7 catch-all should not be possible, as user choice gets vetted in IO, but to be save:
    else:
        print("General Error")



